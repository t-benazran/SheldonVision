import re
import socket
import uuid
import xml.etree.ElementTree as element_tree
from typing import Optional


def find_ip_address() -> Optional[str]:
    ip_lst = [ip for ip in socket.gethostbyname_ex(socket.gethostname())[2]
              if not ip.startswith("127.") and socket.getfqdn(ip) == f"{socket.gethostname()}.corp.microsoft.com"]
    if ip_lst:
        return ip_lst[0]
    else:
        return socket.gethostbyname(socket.gethostname())


def find_mac_address() -> Optional[str]:
    return ':'.join(re.findall('..', '%012x' % uuid.getnode()))


def check_development(func):
    def wrapper(*args, **kwargs):
        if args and hasattr(args[0], "development") and not args[0].development:
            return func(*args, **kwargs)

    return wrapper
