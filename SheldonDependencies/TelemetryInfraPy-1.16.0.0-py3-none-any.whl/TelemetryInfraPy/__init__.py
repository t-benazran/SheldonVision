import getpass
import platform

from applicationinsights import TelemetryClient
from .helpers import *


class Telemetry(TelemetryClient):
    """ Class to send telemetry data to applications insight """

    def __init__(self,
                 application_key: str,
                 module_version="0.0.0",
                 ip: str = None,
                 mac_address: str = None,
                 project_name: str = None,
                 development=False):
        super().__init__(application_key)
        self.development = development
        self.ip = ip
        self.mac_address = mac_address

        self.context.application.ver = module_version
        self.context.user.id = getpass.getuser()
        self.context.device.os_version = platform.platform()
        self.context.device.type = project_name

    def __del__(self):
        super().flush()

    @property
    def __get_mac_address(self):
        return self.mac_address or find_mac_address()

    @property
    def __get_ip(self):
        return self.ip or find_ip_address()

    @check_development
    def track_exception(self, *args, **kwargs):
        super().track_exception(*args, **kwargs, properties={
            "ip": self.__get_ip,
            "mac": self.__get_mac_address,
        })
        super().flush()

    @check_development
    def track_trace(self, *args, **kwargs):
        super().track_trace(*args, **kwargs)
        super().flush()

    @check_development
    def track_event(self, *args, **kwargs):
        super().track_event(*args, **kwargs)
        super().flush()
