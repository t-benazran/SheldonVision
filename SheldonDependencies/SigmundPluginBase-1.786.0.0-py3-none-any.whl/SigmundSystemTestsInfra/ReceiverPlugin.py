import logging
from typing import List

from PyPluginBase.Common import MessageDataTypeEnums

from PyPluginBase.SigmundPluginBase import SigmundPluginBase, Constants
from PyPluginBase.SigmundMsg import SigmundMsg


class ReceiverPlugin(SigmundPluginBase):
    DEFAULT_NAME = "ReceiverPlugin"

    def __init__(self, types_to_receive, input_types_change_list = None, message_type_to_close_network=None, plugin_name=DEFAULT_NAME,
                 wait_registration_ack_timeout_sec=Constants.REGISTRATION_ACK_WAIT_TIMEOUT_SECONDS, verbose=False):
        """
        :param types_to_receive: message types to receive and save in list
        :param plugin_name: name of the sender plugin in network (default: "SenderPlugin")
        :param message_type_to_close_network: message type that if received, the network will be closed (default: None)
        """
        if not isinstance(types_to_receive, list):
            types_to_receive = []

        self.types_to_receive = types_to_receive
        types_to_subscribe_to = types_to_receive.copy()

        if message_type_to_close_network is not None:
            types_to_subscribe_to.append(message_type_to_close_network)

        if Constants.SIGMUND_NETWORK_TIMEOUT_ELAPSED not in types_to_subscribe_to:
            types_to_subscribe_to.append(Constants.SIGMUND_NETWORK_TIMEOUT_ELAPSED)

        SigmundPluginBase.__init__(self, plugin_name, types_to_subscribe_to, [], input_types_change_list,
                                   wait_registration_ack_timeout_sec=wait_registration_ack_timeout_sec)
        self._received_messages = []
        self._is_network_timeout_elapsed = False
        self._message_type_to_close_network = message_type_to_close_network
        self._verbose = verbose

    def plugin_logic(self):
        """ Save received messages in list """
        message = self.get_next_message()

        if message.msg_type in self.types_to_receive:
            self._received_messages.append(message)
            if self._verbose:
                self.send_log(logging.INFO, f"received message type: {message.msg_type}, msg: "
                                            f"{message.get_bytearray_message() if  message.datatype == MessageDataTypeEnums.get_bytearray_message_datatype() else message.get_string_message()}")

        if self._message_type_to_close_network is not None and message.msg_type == self._message_type_to_close_network:
            self.send_log(logging.DEBUG, f"received message to stop network: '{self._message_type_to_close_network}' ")
            self.close_network()

        if message.msg_type == Constants.SIGMUND_NETWORK_TIMEOUT_ELAPSED:
            self._is_network_timeout_elapsed = True

    def get_received_messages(self) -> List[SigmundMsg]:
        return self._received_messages

    def is_network_timeout_elapsed(self):
        return self._is_network_timeout_elapsed
