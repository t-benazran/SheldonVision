import os
import subprocess
import time
import unittest
from threading import Thread, Timer
from typing import List, Tuple
from SigmundSystemTestsInfra.SenderPlugin import SenderPlugin
from SigmundSystemTestsInfra.ReceiverPlugin import ReceiverPlugin
from PyPluginBase.SigmundMsg import SigmundMsg
from PyPluginBase.SigmundPluginBase import SigmundPluginBase

SIGMUND_CORE_EXE_NAME = "Sigmund.Core.exe"
DEFAULT_LOCAL_SIGMUND_CORE__DIR_PATH = os.path.abspath(
    os.path.join(os.path.dirname(__file__), os.pardir, os.pardir, r"x64"))
DEFAULT_PYTHON_PATH = "python"
TIME_WAIT_FOR_REGISTRATION = 2
TIME_WAIT_BETWEEN_TESTS_PASS = 4
TIME_WAIT_BETWEEN_TESTS_FAIL = 6


class SystemTestBase(unittest.TestCase):
    def setUp(self):
        self.plugins_paths_to_plugins_processes_dict = dict()

    def tearDown(self):
        for plugin_path, plugin_process in self.plugins_paths_to_plugins_processes_dict.items():
            if plugin_process.poll() is None:
                plugin_process.kill()

        time.sleep(self.timeout_between_tests)
        self.timeout_between_tests = TIME_WAIT_BETWEEN_TESTS_PASS

    def run(self, result=None):
        self.timeout_between_tests = TIME_WAIT_BETWEEN_TESTS_PASS
        unittest.TestCase.run(self, result)  # call superclass run method

    def run_network(self, network_plugins_path_and_args: List[Tuple[str, str]], sender_plugin: SenderPlugin,
                    types_to_receive: List[str], sigmund_core_dir_path=DEFAULT_LOCAL_SIGMUND_CORE__DIR_PATH,
                    python_path=DEFAULT_PYTHON_PATH, time_wait_for_registration=TIME_WAIT_FOR_REGISTRATION) -> List[SigmundMsg]:
        """
        Run a Sigmund network using the given routing XML, while receiving and saving the given types and using the
            given sender plugin to send its messages to the network.
        :param network_plugins_path_and_args: list of tuples containing a path to a plugin and its arguments to run in
                network (the paths to the plugins' executables should be relative to the Sigmund.Core.exe file location).
                For example: [("PluginDummyConsole.exe", "-n 'dummy'"]
        :param sender_plugin: A sender plugin (PluginSender object)
        :param types_to_receive: List of message types to receive and save from the network (list of strings)
        :param sigmund_core_dir_path: path to the directory containing the Sigmund.Core,exe file and all other
            executables of plugins which should be run in network (and are defined in the routing XML)
        :param python_path: path to the python interpreter (python.exe)
        :param time_wait_for_registration: time for plugins to wait until registration attempt
        :return: The Messages received (list of SigmundMsg objects)
        """
        self.sigmund_core_exe_path = self._get_sigmund_core_exe_path(sigmund_core_dir_path)
        self.python_path = python_path

        # Start Sigmund Core and network on separate process
        self._run_sigmund_core()

        # Start Receiver plugin on separate thread
        receiver = ReceiverPlugin(types_to_receive)
        self._run_plugin_in_separate_thread(receiver, time_wait_for_registration)

        # Start the rest of the network plugins
        self._run_network_plugins(network_plugins_path_and_args, time_wait_for_registration)

        # Start sender and wait for it to finish
        sender_plugin.start_plugin()

        # Get outputs from receiver
        received_messages = receiver.get_received_messages()
        return received_messages

    def run_network_from_json(self, json_file_path: str, types_to_receive: List[str],
                              network_timeout_seconds, additional_core_args="", message_type_to_close_network=None,
                              sigmund_core_dir_path=DEFAULT_LOCAL_SIGMUND_CORE__DIR_PATH,
                              python_path=DEFAULT_PYTHON_PATH, receiver_verbose=False, receiver_plugin: ReceiverPlugin=None) -> List[SigmundMsg]:
        """
        Run a Sigmund network using the given routing XML, while receiving and saving the given types and using the
            given sender plugin to send its messages to the network.
        :param types_to_receive: List of message types to receive and save from the network (list of strings)
        :param json_file_path: Path to json config file.
        :param network_timeout_seconds: Timeout for running network (seconds). If timeout passes before network finished
            running, fails test.
        :param additional_core_args: additional args for sigmund core
        :param message_type_to_close_network: message type that if Receiver receives, the network will be closed (default: None)
            executables of plugins which should be run in network (and are defined in the routing XML)
        :param sigmund_core_dir_path: path to the directory containing the Sigmund.Core,exe file and all other
        :param python_path: path to the python interpreter (python.exe)
        :return: The Messages received (list of SigmundMsg objects)
        """
        self.sigmund_core_exe_path = self._get_sigmund_core_exe_path(sigmund_core_dir_path)
        self.python_path = python_path

        sigmund_core_args = f"-i {json_file_path} --networkRunTimeout {network_timeout_seconds} {additional_core_args}"

        # Start Sigmund Core with json file.
        # Core will Start the rest of the network plugins
        self._run_network_plugins([(self.sigmund_core_exe_path, sigmund_core_args)])

        # Start Receiver plugin and get received messages when receiver plugin is stopped (network closed)
        if receiver_plugin is None:
            receiver = ReceiverPlugin(types_to_receive, message_type_to_close_network=message_type_to_close_network,
                                      verbose=receiver_verbose)
        else:
            receiver = receiver_plugin

        receiver.start_plugin()

        if receiver.is_network_timeout_elapsed():
            self.timeout_between_tests = TIME_WAIT_BETWEEN_TESTS_FAIL
            self.fail("Network timeout elapsed")

        self.assertTrue(receiver.is_plugin_registered, "Receiver failed to register to network")

        return receiver.get_received_messages()

    def is_plugin_process_running(self, plugin_path):
        """
        Checks if the process of the plugin in the given path is closed
        """
        if plugin_path not in self.plugins_paths_to_plugins_processes_dict.keys():
            raise Exception(f"Process was not created for plugin in path {plugin_path}")

        process = self.plugins_paths_to_plugins_processes_dict[plugin_path]
        is_process_running = process.poll() is None

        return is_process_running

    def _run_sigmund_core(self):
        """
        Run Sigmund Core on separate process with given routing XML as input
        :param network_plugins_path_and_args: list of tuples containing a path to a plugin and its arguments (as string)
                to run in network (the paths to the plugins' executables should be relative to the Sigmund.Core.exe
                file location).
        """
        # run sigmund core and wait for network to initialize
        self._run_plugin_in_separate_process([self.sigmund_core_exe_path], plugin_path=self.sigmund_core_exe_path)

    def _run_network_plugins(self, network_plugins_path_and_args: List[Tuple[str, str]],
                             time_wait_for_registration=TIME_WAIT_FOR_REGISTRATION):
        # run network plugins
        for [plugin_path, args] in network_plugins_path_and_args:
            abs_plugin_path = plugin_path
            # if path does not exist, use as relative from sigmund exe path
            if not os.path.isfile(abs_plugin_path):
                relative_plugin_path = os.path.join(self.sigmund_core_exe_path, os.pardir, plugin_path)
                if os.path.isfile(relative_plugin_path):
                    abs_plugin_path = relative_plugin_path
                else:
                    raise FileNotFoundError(f"Plugin path {plugin_path} was not found")

            plugin_run_command_and_args_list = [abs_plugin_path] + args.split(" ")

            # if python plugin - add python path as first argument in command
            if ".py" in plugin_path:
                plugin_run_command_and_args_list.insert(0, self.python_path)

            plugin_dir = os.path.dirname(abs_plugin_path)
            self._run_plugin_in_separate_process(plugin_run_command_and_args_list, plugin_path,
                                                 time_wait_for_registration, working_dir=plugin_dir)

    def _run_plugin_in_separate_process(self, plugin_run_arguments: List[str], plugin_path: str,
                                        time_wait_for_registration=TIME_WAIT_FOR_REGISTRATION, working_dir=None):
        """
        Run plugin with given run arguments in separate process
        :param plugin_run_arguments: list of arguments defining the command to run plugin (including plugin path)
        :param plugin_path: path to the plugin (in order to save the process matching the plugin)
        :param time_wait_for_registration: time for plugin to wait until registration attempt
        """
        if working_dir is None:
            working_dir = os.getcwd()

        try:
            process = subprocess.Popen(plugin_run_arguments, stderr=subprocess.PIPE, stdout=subprocess.PIPE,
                                       cwd=working_dir)
            self.plugins_paths_to_plugins_processes_dict[plugin_path] = process
            time.sleep(time_wait_for_registration)
        except FileNotFoundError as e:
            raise FileNotFoundError(f"File not found: {plugin_path}")

    @staticmethod
    def _run_plugin_in_separate_thread(plugin: SigmundPluginBase,
                                       time_wait_for_registration=TIME_WAIT_FOR_REGISTRATION):
        """
        Start given plugin in separate process
        :param plugin: the plugin object to start
        :param time_wait_for_registration: time for plugin to wait until registration attempt
        """
        plugin_thread = Thread(target=plugin.start_plugin, daemon=True)
        plugin_thread.start()
        time.sleep(time_wait_for_registration)

    @staticmethod
    def _get_sigmund_core_exe_path(sigmund_core_dir_path):
        """ Get the path to the Sigmund.Core.exe file to run """
        if not is_running_in_build_server():
            return os.path.join(sigmund_core_dir_path, SIGMUND_CORE_EXE_NAME)
        else:
            build_server_sigmund_core_exe_dir_path = \
                f"{os.environ.get('BUILD_SOURCESDIRECTORY')}\\" \
                f"{os.environ.get('BuildConfiguration')}\\{os.environ.get('BuildPlatform')}\\" \
                f"{os.environ.get('BuildConfiguration')}_win10-{os.environ.get('BuildPlatform')}"

            return os.path.join(build_server_sigmund_core_exe_dir_path, SIGMUND_CORE_EXE_NAME)


def is_running_in_build_server():
    """ Check if running in Build Server - if environment variable 'ComponentVersion' exists """
    return os.environ.get('ComponentVersion') is not None
