import logging
import time
from threading import Timer, Thread
from PyPluginBase.SigmundPluginBase import SigmundPluginBase
from PyPluginBase.SigmundMsg import SigmundMsg


class SenderPlugin(SigmundPluginBase):
    DEFAULT_TIME_TO_WAIT_SEC = 0.5
    TIME_WAIT_FOR_NETWORK_CLOSE_SEC = 10
    DEFAULT_NAME = "SenderPlugin"

    def __init__(self, network_runtime_sec=DEFAULT_TIME_TO_WAIT_SEC, messages_to_send=None, plugin_name=DEFAULT_NAME,
                 input_types=None, output_types=None):
        """
        :param network_runtime_sec: Time in seconds for network to run before stopping it (Default: 30)
        :param messages_to_send: Messages to send to network - list of PyPluginBase.Common.SigmundMsg objects (Default: None - no messages)
        :param plugin_name: Name of the sender plugin in network (default: "SenderPlugin"
        :param input_types: Expected input types for sender plugin (Default: None - no input types)
        :param output_types: Expected output types for sender plugin (Default: None - no output types)
        """
        if input_types is None:
            input_types = []
        if output_types is None:
            output_types = []

        SigmundPluginBase.__init__(self, plugin_name, input_types, output_types)
        self.network_runtime_sec = network_runtime_sec
        self.messages_to_send = messages_to_send if type(messages_to_send) is list else []
        self.timer = Timer(network_runtime_sec, self.on_timer_expired)

    def on_init_plugin(self):
        # Start sending messages
        send_messages_thread = Thread(target=self.send_messages, daemon=True)
        send_messages_thread.start()

        # Start timer
        self.timer.daemon = True
        self.timer.start()

        # Wait for send messages to finish or timeout to finish
        send_messages_thread.join(self.network_runtime_sec)

    def plugin_logic(self):
        # Keep listening to network messages - in order to handle control messages
        received_message = self.get_next_message()

    def send_messages(self):
        """ Sends all messages in messages_to_send"""
        self.send_log(logging.DEBUG, "Starting to send messages")
        for msg in self.messages_to_send:
            if isinstance(msg, SigmundMsg):
                self.send_message(msg.msg_type, msg.msg, msg.msg_metadata)

        self.send_log(logging.DEBUG, "Finished sending messages")

    def on_timer_expired(self):
        """ Closes network after timer expires """
        self.send_log(logging.DEBUG, "Network runtime finished")
        self.close_network()

    def on_stop_plugin(self):
        """ Cancel timer if plugin is stopped"""
        self.timer.cancel()
