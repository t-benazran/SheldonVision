import os
import unittest
from SigmundSystemTestsInfra.SenderPlugin import SenderPlugin
from SigmundSystemTestsInfra.SystemTestBase import SystemTestBase
from PyPluginBase.SigmundPluginBase import SigmundPluginBase
from PyPluginBase.SigmundMsg import SigmundMsg

TESTS_WAIT_TIMEOUT = 0.5
DUMMY_PLUGIN_NAME = "dummy"
DUMMY_PLUGIN_EXE_PATH = r".\PluginDummyConsole.exe"
SENDER_PLUGIN_NAME = "sender"
SENDER_MSG_TYPE = "sent_msg"
NUM_MSGS_TO_SEND = 50

SIGMUND_CORE_DIR_REL_PATH = r"..\..\x64"
SIGMUND_CORE_DIR_ABS_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), SIGMUND_CORE_DIR_REL_PATH))


class ExampleSystemTest(SystemTestBase):
    """
    Example system test :
     - test that receiverPlugin gets all of the messages SenderPlugin sent
     - test that the dummy plugin specified to run in separate process receives a registration ack message
    """
    def test1(self):
        network_plugins_path_and_args = [(DUMMY_PLUGIN_EXE_PATH, f"-n {DUMMY_PLUGIN_NAME}")]
        messages_to_send = [SigmundMsg(SENDER_MSG_TYPE, SENDER_PLUGIN_NAME, str(i), "") for i in range(NUM_MSGS_TO_SEND)]
        sender_plugin = SenderPlugin(TESTS_WAIT_TIMEOUT, messages_to_send=messages_to_send,
                                     plugin_name=SENDER_PLUGIN_NAME)

        # listen to messages sent from sender and messages sent to the dummy plugin
        types_to_receive = [SENDER_MSG_TYPE, DUMMY_PLUGIN_NAME]

        # run the network with dummy plugin and sender
        received_msgs = self.run_network(network_plugins_path_and_args, sender_plugin, types_to_receive,
                                         sigmund_core_dir_path=SIGMUND_CORE_DIR_ABS_PATH)

        received_sender_msgs = [msg for msg in received_msgs if msg.msg_type == SENDER_MSG_TYPE]
        received_dummy_plugin_msgs = [msg for msg in received_msgs if msg.msg_type == DUMMY_PLUGIN_NAME]

        # Check that all sender msgs were received
        self.assertEqual(len(received_sender_msgs), NUM_MSGS_TO_SEND,
                         f"Did not receive all of the messages sender sent - received "
                         f"{len(received_sender_msgs)}\{NUM_MSGS_TO_SEND}")

        # check that dummy plugin connected to network (received ack)
        is_dummy_ack_message_received = False
        for msg in received_dummy_plugin_msgs:
            if SigmundPluginBase.is_register_ack_type_control(msg):
                is_dummy_ack_message_received = True

        self.assertTrue(is_dummy_ack_message_received,
                        "Ack message for dummy plugin registration was not received - connection was unsuccessful")


if __name__ == '__main__':
    unittest.main()
