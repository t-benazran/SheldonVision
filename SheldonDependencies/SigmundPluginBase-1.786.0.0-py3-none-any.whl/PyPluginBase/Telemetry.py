class Telemetry:
    """
    Telemetry is a class that is used to send data to the server.
    """

    __metrics_dictionary = {}

    def __init__(self, metrics={}):
        from TelemetryInfraPy import Telemetry as TelemetryPy

        self.__client = TelemetryPy(application_key="f1be8882-9888-4a10-a75e-cb8aa6b49acb")
        self.__metrics_dictionary = metrics

    def set_metrics_dictionary(self, new_metrics={}):
        self.__metrics_dictionary = new_metrics

    def track_trace(self, trace: str):
        self.__client.track_trace(trace, self.__metrics_dictionary)

    def track_exception(self, *args, **kwargs):
        """
        Track an exception.
        Usage: track_exception(*sys.exc_info())
        """
        self.__client.track_exception(*args, **kwargs)

    def track_event(self, name: str):
        self.__client.track_event(name, self.__metrics_dictionary)

    def flush(self):
        self.__client.flush()
