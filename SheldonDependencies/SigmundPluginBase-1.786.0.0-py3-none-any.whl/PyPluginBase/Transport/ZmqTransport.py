import logging
import os
import signal
from typing import Callable
import zmq
import time
import threading
from PyPluginBase.PluginStoppedException import PluginStoppedException
from PyPluginBase.SigmundMsg import SigmundMsg
from PyPluginBase.Common import Constants, MessageDataTypeEnums
from PyPluginBase.Transport.ISigmundTransport import ISigmundTransport


class ZmqTransport(ISigmundTransport):
    def __init__(self, plugin_name: str, ip: str, sub_port: str, pub_port: str, keep_alive_port: str,
                 send_log_func: Callable[[int, str], None]) -> None:
        super().__init__(plugin_name)
        self.pub_port = pub_port
        self.sub_port = sub_port
        self.keep_alive_port = keep_alive_port
        self.ip = ip
        self.sub_socket = None
        self.pub_socket = None
        self.keep_alive_socket = None
        self.keep_alive_thread = None
        self.keep_alive_thread_stop_event = threading.Event()
        self.send_message_lock = threading.Lock()  # lock for sending messages
        self.send_log = send_log_func

    def init(self) -> None:
        """"
        Create Publisher and Subscriber using NetMQ.
        Later, Subscriber will assign specific filters,
        which are the input types of this plugin
        """
        context = zmq.Context()
        self.sub_socket = context.socket(zmq.SUB)
        self.pub_socket = context.socket(zmq.PUB)
        self.keep_alive_socket = context.socket(zmq.SUB)
        self.pub_socket.connect("tcp://" + self.ip + ":" + Constants.PUB_PORT)
        self.sub_socket.connect("tcp://" + self.ip + ":" + Constants.SUB_PORT)
        self.keep_alive_socket.connect("tcp://" + self.ip + ":" + Constants.KEEP_ALIVE_PORT)

        # Remember that this enum is different in C# format
        # Minimal sleep time for publisher socket to connect.
        # This sleeps enables registration of publisher to type only after socket is ready.
        time.sleep(Constants.SOCKET_OPEN_WAIT_TIME_SECONDS)

    def close(self) -> None:
        self.keep_alive_thread_stop_event.set()
        if self.keep_alive_thread is not None:
            self.keep_alive_thread.join()
        self.sub_socket.close()
        self.pub_socket.close()
        self.keep_alive_socket.close()

    def unsubscribe_type(self, msg_type: str) -> None:
        self.sub_socket.setsockopt_string(zmq.UNSUBSCRIBE, msg_type)

    def subscribe_type(self, msg_type: str) -> None:
        """
        set one filter to plugin NetMQ subscriber
        :param msg_type: filter, string to subscribe for.
        """
        self.sub_socket.setsockopt_string(zmq.SUBSCRIBE, msg_type)

    def get_next_msg(self) -> SigmundMsg:
        message_received = self.sub_socket.recv_multipart()
        return self.__zmq_to_sigmund_msg__(message_received)

    def get_next_msg_timeout(self, timeout_ms=None) -> SigmundMsg:
        """ Variant for get_next_message that will block up until timeout_msec
            if no message arrives within timeout_msec it returns None,
            otherwise it will return the message """
        if timeout_ms is None:
            return self.get_next_msg()

        if self.sub_socket.poll(timeout_ms) == 0:
            return None

        return self.get_next_msg()

    @staticmethod
    def __zmq_to_sigmund_msg__(zmq_msg):
        TYPE_LOCATION_IN_MESSAGE = 0
        FROM_LOCATION_IN_MESSAGE = 1
        DATA_TYPE_LOCATION_IN_MESSAGE = 2
        MSG_LOCATION_IN_MESSAGE = 3
        META_DATA_LOCATION_IN_MESSAGE = 4

        msg_type = zmq_msg[TYPE_LOCATION_IN_MESSAGE].decode()
        msg_from = zmq_msg[FROM_LOCATION_IN_MESSAGE].decode()

        received_datatype = int.from_bytes(zmq_msg[DATA_TYPE_LOCATION_IN_MESSAGE], byteorder='big')
        if received_datatype == int(MessageDataTypeEnums.get_str_message_datatype()):
            msg = zmq_msg[MSG_LOCATION_IN_MESSAGE].decode()
        else:
            msg = zmq_msg[MSG_LOCATION_IN_MESSAGE]

        msg_metadata = zmq_msg[META_DATA_LOCATION_IN_MESSAGE].decode()
        return SigmundMsg(msg_type, msg_from, msg, msg_metadata)

    def send_message(self, message_type: str, message: object, metadata: str = "") -> None:
        message_datatype = MessageDataTypeEnums.get_bytearray_message_datatype()
        if isinstance(message, str):
            message_datatype = MessageDataTypeEnums.get_str_message_datatype()
            message = message.encode()
        # "send_multipart" does not handle string frames, so msg have to be encoded.
        msg = [message_type.encode(), self.plugin_name.encode(), message_datatype.to_bytes(4, 'big'), message,
               metadata.encode()]
        self.send_message_lock.acquire()
        self.pub_socket.send_multipart(msg)
        self.send_message_lock.release()

    def start_keep_alive(self, plugin_stop_func: Callable[[], None]) -> None:
        self.keep_alive_thread = threading.Thread(target=self.keep_alive_thread_func, args=(plugin_stop_func,),
                                                  daemon=True)
        self.keep_alive_thread.start()

    def stop_keep_alive(self) -> None:
        self.keep_alive_thread_stop_event.set()
        if self.keep_alive_thread is not None:
            self.keep_alive_thread.join()

    def keep_alive_thread_func(self, plugin_stop_func: Callable[[], None]):
        # subscribe to keepAlive message
        self.keep_alive_socket.setsockopt_string(zmq.SUBSCRIBE, Constants.SIGMUND_KEEP_ALIVE_MESSAGE)

        ms_no_keep_alive_received = 0
        while not self.keep_alive_thread_stop_event.is_set():
            num_messages_received = self.keep_alive_socket.poll(Constants.TIME_TO_POLL_FOR_KEEP_ALIVE_MESSAGE_MILLISECONDS)

            if num_messages_received == 0:  # no keep alive message received
                ms_no_keep_alive_received += Constants.TIME_TO_POLL_FOR_KEEP_ALIVE_MESSAGE_MILLISECONDS

                if ms_no_keep_alive_received >= Constants.CORE_DISCONNECT_NO_KEEP_ALIVE_TIMEOUT_SECONDS * 1000:
                    self.send_log(logging.ERROR, f"Sigmund Core disconnected - did not receive keep alive message in "
                                                 f"timeout ({Constants.CORE_DISCONNECT_NO_KEEP_ALIVE_TIMEOUT_SECONDS} seconds)")

                    try:
                        plugin_stop_func()
                    except PluginStoppedException:
                        os.kill(os.getpid(), Constants.ERROR_EXIT_CODE)

            else:
                ms_no_keep_alive_received = 0
                self.keep_alive_socket.recv()
