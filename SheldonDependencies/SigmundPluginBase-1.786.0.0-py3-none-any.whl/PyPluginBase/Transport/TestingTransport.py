from queue import Queue, Empty

from PyPluginBase.SigmundMsg import SigmundMsg
from PyPluginBase.SigmundPluginBase import SigmundPluginBase
from PyPluginBase.Transport.ISigmundTransport import ISigmundTransport

MSEC_IN_SEC = 1000


class TestingTransport(ISigmundTransport):
    def __init__(self, plugin_name: str, is_save_log: bool = False) -> None:
        super().__init__(plugin_name)
        self.is_save_log = is_save_log
        self.input_queue = Queue()
        self.output_queue = Queue()
        self.input_types = []

    def unsubscribe_type(self, msg_type: str) -> None:
        if msg_type in self.input_types:
            self.input_types.remove(msg_type)

    def subscribe_type(self, msg_type: str) -> None:
        if msg_type not in self.input_types:
            self.input_types.append(msg_type)

    def get_next_msg(self) -> SigmundMsg:
        return self.input_queue.get()

    def get_next_msg_timeout(self, timeout_ms=None) -> SigmundMsg:
        try:
            timeout_sec = timeout_ms / MSEC_IN_SEC
            return self.input_queue.get(timeout=timeout_sec)
        except Empty:
            return None

    def send_message(self, message_type: str, message: object, metadata: str = "") -> None:
        if message_type == SigmundPluginBase.SIGMUND_LOG_TYPE and not self.is_save_log:
            return

        sigmund_msg = SigmundMsg(message_type, self.plugin_name, message, metadata)
        self.output_queue.put(sigmund_msg)
        if message_type in self.input_types:
            self.input_queue.put(sigmund_msg)

    def send_message_to_plugin(self, sigmund_msg: SigmundMsg) -> None:
        self.input_queue.put(sigmund_msg)

    def get_output_message(self) -> SigmundMsg:
        return self.output_queue.get()
