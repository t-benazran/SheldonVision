from PyPluginBase.SigmundMsg import SigmundMsg
from typing import Callable

class ISigmundTransport:
    def __init__(self, plugin_name):
        self.plugin_name = plugin_name

    def init(self) -> None:
        pass

    def start_keep_alive(self, plugin_stop_func: Callable[[], None]) -> None:
        pass

    def stop_keep_alive(self) -> None:
        pass

    def close(self) -> None:
        pass

    def unsubscribe_type(self, msg_type: str) -> None:
        pass

    def subscribe_type(self, msg_type: str) -> None:
        pass

    def get_next_msg(self) -> SigmundMsg:
        pass

    def get_next_msg_timeout(self, timeout_ms=None) -> SigmundMsg:
        pass

    def send_message(self, message_type: str, message: object, metadata: str = "") -> None:
        pass
