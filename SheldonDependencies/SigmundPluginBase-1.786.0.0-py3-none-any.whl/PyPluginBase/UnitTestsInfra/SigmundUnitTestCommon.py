from SigmundProtobufPy.LogMessageType_pb2 import LogMessageTypeProto
from SigmundProtobufPy.PluginInformation_pb2 import PluginInformationProto
from PyPluginBase import SigmundPluginBase
from PyPluginBase.Common import Constants
from PyPluginBase.SigmundMsg import SigmundMsg
from PyPluginBase.Transport import ISigmundTransport
from PyPluginBase.DummyPlugin import DummyPlugin


def create_registry_ack_msg(plugin_name):
    return f"{Constants.CONTROL_MSG_TYPE}{Constants.SIGMUND_REGISTER_ACK}({plugin_name})"


def send_registration_ack_message(plugin_name: str, transport: ISigmundTransport):
    reg_ack = create_registry_ack_msg(plugin_name)
    min_log_level_proto = LogMessageTypeProto.Name(2)

    transport.send_message_to_plugin(
        SigmundMsg(plugin_name, Constants.SIGMUND_MSG_TYPE, reg_ack, str(min_log_level_proto)))


def send_stop_message(plugin_name: str, transport: ISigmundTransport):
    stop_msg = SigmundMsg(plugin_name, Constants.SIGMUND_MSG_TYPE,
                          Constants.CONTROL_MSG_TYPE + Constants.SIGMUND_CLOSE_PLUGIN, "")
    transport.send_message_to_plugin(stop_msg)


def check_plugin_registration_ask_message(plugin: SigmundPluginBase, registration_ask: SigmundMsg):
    is_name_equal = plugin.plugin_name == registration_ask.msg_from

    is_register_type = registration_ask.msg_type.startswith(
        f"{Constants.SIGMUND_MSG_TYPE + Constants.SIGMUND_REGISTER_TYPE}")

    plugin_information = PluginInformationProto()
    plugin_information.ParseFromString(registration_ask.msg)
    is_plugin_information_received = (plugin.plugin_name == plugin_information.PluginName
                                      and set(plugin.input_types) == set(plugin_information.InputTypes)
                                      and set(plugin.output_types) == set(plugin_information.OutputTypes))

    return is_name_equal and is_register_type and is_plugin_information_received


def run_plugin_and_check_registration_ask(plugin: SigmundPluginBase, transport: ISigmundTransport):
    plugin.start_plugin()
    reg_ask = transport.get_output_message()
    return check_plugin_registration_ask_message(plugin, reg_ask)


def check_test_init(plugin: SigmundPluginBase, transport: ISigmundTransport):
    send_registration_ack_message(plugin.plugin_name, transport)
    send_stop_message(plugin.plugin_name, transport)
    return run_plugin_and_check_registration_ask(plugin, transport)
