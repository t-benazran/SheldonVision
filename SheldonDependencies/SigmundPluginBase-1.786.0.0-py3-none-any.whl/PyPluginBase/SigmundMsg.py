from PyPluginBase.Common import MessageDataTypeEnums


class SigmundMsg:
    def __init__(self, msg_type, msg_from, msg, msg_metadata):
        self.msg_type = msg_type
        self.msg_from = msg_from
        self.msg = msg
        self.msg_metadata = msg_metadata

        if isinstance(msg, str):
            self.datatype = MessageDataTypeEnums.get_str_message_datatype()
        else:
            self.datatype = MessageDataTypeEnums.get_bytearray_message_datatype()

    def get_string_message(self):
        return str(self.msg)

    def get_bytearray_message(self):
        return bytearray(self.msg)