WINDOW_INDEX_COLUMN_NAME = "WindowIndex"
CYCLE_NUMBER = 'CycleNumber'
WINDOW_INDEX_IN_CYCLE = 'WindowIndexInCycle'
WINDOW_TYPE = 'WindowType'
FREQ = 'Freq'
AXIS = 'Axis'
NUMBER_ANTTENAS_PER_AXIS = 'NumberAntPerAxis'
ANT = 'Ant'