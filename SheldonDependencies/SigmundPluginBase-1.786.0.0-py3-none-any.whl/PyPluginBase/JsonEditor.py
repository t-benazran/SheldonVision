import json
import sys

PLUGIN_NAME = 'pluginName'


def edit_json(path_to_json, values_dict):
    json_data = get_json_data(path_to_json)

    for key in values_dict:
        json_data['Aliases'][key] = values_dict[key].replace('\\\\', '\\').replace('/', '\\')

    save_json(path_to_json, json_data)


def get_json_data(path_to_json):
    with open(path_to_json) as json_file:
        return json.load(json_file)


def get_plugins_names(path_to_json):
    json_data = get_json_data(path_to_json)
    return [plugin[PLUGIN_NAME] for plugin in json_data['Launchables'].values()]


def save_json(path_to_json, json_data):
    with open(path_to_json, 'w') as outfile:
        json.dump(json_data, outfile, indent=2)


def parse_args(args):
    values_dict = {}

    for i in range(0, len(args), 2):
        if i + 1 < len(args):
            values_dict[args[i]] = args[i + 1]

    return values_dict


def main():
    parsed_args = parse_args(sys.argv[2:])
    path_to_json = sys.argv[1]
    edit_json(parsed_args, path_to_json)


if __name__ == '__main__':
    main()
