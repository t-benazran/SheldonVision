import json
import logging
import re
import sys
import threading
import os
import time
from abc import ABC, abstractmethod
from typing import List

import jsonpickle
import pkg_resources

from SigmundProtobufPy.CloseType_pb2 import SigmundCloseTypeProto
from SigmundProtobufPy.LogMessageType_pb2 import LogMessageTypeProto
from SigmundProtobufPy.Counters_pb2 import PluginCountersProto
from SigmundProtobufPy.PluginInformation_pb2 import PluginInformationProto

from PyPluginBase.Common import Constants, CounterType, MessageTypeToHandle
from PyPluginBase.IntervalTimer import IntervalTimer
from PyPluginBase.PluginLogger import PluginLogger
from PyPluginBase.PluginStoppedException import PluginStoppedException
from PyPluginBase.Telemetry import Telemetry
from PyPluginBase.Transport.ISigmundTransport import ISigmundTransport
from PyPluginBase.Transport.ZmqTransport import ZmqTransport
from PyPluginBase.SigmundMsg import SigmundMsg


class SigmundPluginBase(ABC):
    """
    Abstract base class (ABC for inheriting abstract class) for plugins to join Sigmund System.
    Each added plugin should start running only after SigmundCore is up.
    """
    sigmundTransport: ISigmundTransport
    SIGMUND_LOG_TYPE: str = "Sigmund.Log"  # todo protobuf
    SIGMUND_TYPE = "Sigmund"  # todo protobuf
    CONTROL_CHANGE_INPUT_TYPE = "ChangeInput"  # todo protobuf
    PLAYER_PLAY_NEXT_FRAMES_MESSAGE = "PlayerPlayNextFrames"

    def __init__(self, plugin_name: str, input_types: list, output_types: list,
                 input_types_change_list: list = None, output_types_change_list: list = None, pass_through_types: list = None,
                 sigmund_transport: ISigmundTransport = None,
                 master=False, master_num_of_frames_to_req=Constants.DEFAULT_PLAY_FRAMES_NUM,
                 wait_registration_ack_timeout_sec=Constants.REGISTRATION_ACK_WAIT_TIMEOUT_SECONDS,
                 registration_retry_attempts=Constants.NUMBER_OF_REGISTRATION_RETRIES, plugins_to_close_after=None,
                 ip=Constants.IP_ADDRESS, disable_telemetry=False) -> None:
        super().__init__()
        self.wait_for_registration_ack_timeout_sec = wait_registration_ack_timeout_sec
        self.registration_retries = registration_retry_attempts
        self.plugin_name = plugin_name
        self._original_plugin_name = plugin_name
        self.input_types = input_types
        self.output_types = output_types
        self.is_plugin_enable = True
        self.is_plugin_registered = False
        self.is_registration_timeout_raised = False
        self._is_master_plugin = master
        self._master_num_of_frames_to_req = master_num_of_frames_to_req
        self.is_plugin_master = False
        self._plugins_to_close_after = plugins_to_close_after if plugins_to_close_after is not None else []
        self.messages_counters = PluginCountersProto()
        self.send_counters_timer = IntervalTimer(Constants.SEND_COUNTERS_INTERVAL_SEC, self.send_plugin_counters)
        self.min_sigmund_log_level = logging.NOTSET

        self.input_change_types_dict = dict()
        self.output_change_types_dict = dict()
        self.pass_through_change_types_dict = dict()

        self.fill_input_change_types_dict(input_types_change_list)
        self.fill_output_change_types_dict(output_types_change_list)
        self.fill_pass_through_change_types_dict(pass_through_types)

        if sigmund_transport is None:
            self.sigmundTransport = ZmqTransport(plugin_name, ip, Constants.SUB_PORT,
                                                 Constants.PUB_PORT, Constants.KEEP_ALIVE_PORT, self.send_log)
        else:
            self.sigmundTransport = sigmund_transport
        self._logger = PluginLogger.get_logger(self.__class__.__name__)
        if not disable_telemetry:
            self.__setup_telemetry()

    @property
    def _telemetry(self):
        if self.__telemetry is None:
            from unittest.mock import MagicMock
            return MagicMock()
        else:
            return self.__telemetry

    def __setup_telemetry(self):
        try:
            self.__telemetry = Telemetry(metrics=self.__default_telemetry_metrics)
            self.__telemetry.track_event("Plugin start")
            if len(self._plugins_to_close_after) > 0:
                self.__telemetry.track_event("PluginsToCloseAfter")
        except:
            self.send_log(logging.ERROR, "Failed to setup telemetry")
        
    
    @abstractmethod
    def plugin_logic(self):
        """ Core logic of the plugin. Will be running infinitely until stop_plugin is operated. """
        pass

    @property
    def __default_telemetry_metrics(self):
        return {
            "Plugin exe name": self.plugin_name,
            "Plugin version": self.version
        }

    @property
    def version(self):
        """ Get class version property"""
        return pkg_resources.get_distribution("SigmundPluginBase").version

    def start_plugin(self):
        """
        Starts the plugin.
        Calls the init_plugin and then will call the plugin_logic infinitely method until stop_plugin is called.
        """
        try:
            self.init_plugin()

            while self.is_plugin_enable:
                self.plugin_logic()

        except PluginStoppedException:
            # if plugin stopped, break from loop
            self.send_log(logging.INFO, f"Plugin {self.plugin_name} stopped")

        except Exception as e:
            self.send_log(logging.FATAL, f"Exception thrown: {e}")
            self.on_plugin_exception(e)
            self._stop_plugin_notify_close()
            self._telemetry.track_exception(*sys.exc_info())
        self.sigmundTransport.close()

    def stop_plugin(self):
        """
        Method to stop plugin and throw exception that plugin stopped.
        """
        self.send_log(logging.INFO, "Starting Stop")
        self.send_counters_timer.stop()
        # sending final counters before closing
        self.send_plugin_counters()
        self._stop_plugin_notify_close()
        raise PluginStoppedException

    def _stop_plugin_notify_close(self):
        """
        For internal use - stops the plugin and notifies network of closing.
        """
        self.on_stop_plugin()

        # Stop checking keep alive - in thread to avoid deadlock if stop was called from keep alive thread
        # Then sleep for 2 * time keep alive thread polls for to ensure it stops
        stop_keep_alive_thread = threading.Thread(target=self.sigmundTransport.stop_keep_alive, daemon=True)
        stop_keep_alive_thread.start()
        time.sleep((Constants.TIME_TO_POLL_FOR_KEEP_ALIVE_MESSAGE_MILLISECONDS * 2) / 1000)

        if self.is_plugin_registered:
            self.send_counters_timer.stop()
            self.send_log(logging.NOTSET, "Sending closing message")
            self.send_message(self.SIGMUND_TYPE, Constants.SIGMUND_PLUGIN_CLOSING)
            self.send_message(SigmundPluginBase.plugin_closing_msg_type(self._original_plugin_name), "")

        self.is_plugin_enable = False
        self._telemetry.flush()

    def stop_plugins_list(self, plugins_names_to_stop: List[str]):
        """
        Stop the plugins in the given list.

        Parameters:
        -----------
            plugins_names_to_stop : List[str]
                List of plugin names to stop.
        """
        for plugin_name in plugins_names_to_stop:
            self.send_close_plugin(plugin_name)

    def raise_network_plugins (self, json_path):
        """
        Sends network json file to Sigmund core for raising relevant plugins.

        Parameters:
        -----------
            json_path : str
                Path to the network json file.
        """
        if not os.path.isfile(json_path):
            error_message = f"JSON file is not found: {json_path}."
            self.send_log(logging.ERROR, error_message)
            raise Exception(error_message)

        json_as_string = open(json_path, "r").read()
        self.send_message(message_type=self.SIGMUND_TYPE, message=Constants.SIGMUND_RAISE_NETWORK,
                          metadata=json_as_string)

    def on_stop_plugin(self):
        """
        Called when plugin is stopped.
        Plugins can override and implement if special behaviour is needed when stopping plugin.
        """
        pass

    def on_init_plugin(self):
        """
        Called when plugin is initialized before the main loop.
        Plugins can override and implement.
        """
        pass

    def on_message_pass_through(self, message: SigmundMsg):
        """
        Called when message need to be passed through.
        Plugins can override and implement if special behavior is needed when plugin receives message to pass through

        Parameters
        ----------
            message : SigmundMsg
                Message to pass through.
        """
        pass

    def on_plugin_exception(self, ex: Exception):
        """
        Called when plugin catches exception.

        Parameters
        ----------
            ex : Exception
        """
        self._telemetry.track_exception(*sys.exc_info())
        pass

    def close_network(self, close_type=SigmundCloseTypeProto.Value('Soft')):
        """
        Send message to core to close the entire network. Close types:
            Soft Close - wait for plugins to finish handling the current messages and then close.
            Hard Close - kill the processes immediately.
        """
        message = ""

        if close_type == SigmundCloseTypeProto.Value('Soft'):
            message = Constants.SIGMUND_CLOSE_NETWORK_SOFT
        elif close_type == SigmundCloseTypeProto.Value('Hard'):
            message = Constants.SIGMUND_CLOSE_NETWORK_HARD

        self.send_message(self.SIGMUND_TYPE, message)

    def send_close_plugin(self, plugin_name):
        """
        Close plugin request.
        """
        self.send_message(plugin_name, f"{Constants.CONTROL_MSG_TYPE}{Constants.SIGMUND_CLOSE_PLUGIN}")

    def init_plugin(self):
        self.init_transport()
        self.set_subscriber_for_control_message()
        self.register_to_network()
        # after registration finished, start keep alive logic
        self.sigmundTransport.start_keep_alive(self.stop_plugin)

        if self._is_master_plugin:  # If Master flag is enable, send Master Req to Network
            self.master_req_to_network()

        self.start_sending_counters()
        self.on_init_plugin()

    def register_to_network(self):
        """ Register plugin to Sigmund network"""

        for registration_attempt in range(self.registration_retries):
            self.send_log(logging.DEBUG,
                          f"Starting registration attempt {registration_attempt + 1}/{self.registration_retries}")
            self.send_registration_message()

            # wait until timeout for registration ack
            self.wait_for_registration_ack()

            if self.is_plugin_registered:
                self.set_subscribers()
                self.send_log(logging.DEBUG, "SetSubscribers completed")
                break

        if not self.is_plugin_registered:
            raise Exception("Registration Ack message not received"
                            " - make sure Sigmund Core is running before running plugin")

    def create_registration_info(self) -> PluginInformationProto:
        plugin_registration_info = PluginInformationProto()
        plugin_registration_info.PluginName = self.plugin_name
        plugin_registration_info.PluginVersion = pkg_resources.get_distribution("SigmundPluginBase").version
        plugin_registration_info.PluginProcessName = os.path.basename(sys.argv[0]) if sys.argv[0] else ""

        for input_type in [self.input_types]:
            plugin_registration_info.InputTypes.extend(input_type)

        for output_type in [self.output_types]:
            plugin_registration_info.OutputTypes.extend(output_type)

        return plugin_registration_info

    def send_registration_message(self):
        # Send RegisterPlugin message to Sigmund
        registration_msg_type = Constants.SIGMUND_MSG_TYPE + Constants.SIGMUND_REGISTER_TYPE
        self.send_message(registration_msg_type, self.create_registration_info().SerializeToString())

    def wait_for_registration_ack(self):
        """ wait to receive registration ack message """
        msg_timeout_ms = self.wait_for_registration_ack_timeout_sec * 1000

        while not self.is_plugin_registered:
            message = self.sigmundTransport.get_next_msg_timeout(msg_timeout_ms)

            if message is None:
                self.send_log(logging.DEBUG,
                              f"No registration message received at define time - {self.wait_for_registration_ack_timeout_sec} seconds")
                return
            elif self.is_control_type(message) and self.is_register_ack_type_control(message):
                self.handle_register_ack(message)
                self.is_plugin_registered = True
                self.send_log(logging.DEBUG, f"RegisterAck message received: {message.msg}")

    def handle_register_ack(self, message):
        # if plugin name already exists in network - plugin's name is updated
        new_name, min_log_level = self.parse_register_ack_type_message(message)
        self.min_sigmund_log_level = min_log_level
        if not new_name == self.plugin_name:
            self.unsubscribe_to_single_type(self.plugin_name)
            self.subscribe_to_single_type(new_name)
            self.plugin_name = new_name
            self.sigmundTransport.plugin_name = new_name

    def start_sending_counters(self):
        self.send_plugin_counters()
        self.send_counters_timer.start()

    def send_plugin_counters(self):
        messages_counters_bytes = self.messages_counters.SerializeToString()
        self.send_message(f"{self.SIGMUND_TYPE}:{Constants.PLUGIN_COUNTERS_MSG_TYPE}", messages_counters_bytes)

    def is_handle_message_in_base(self, sigmund_msg):
        if self.is_control_type(sigmund_msg):
            return True

        if SigmundPluginBase.is_plugin_closing_type(sigmund_msg):
            closing_plugin_name = SigmundPluginBase.get_plugin_closing_type_from_closing_plugin_msg_type(sigmund_msg.msg_type)
            return closing_plugin_name in self._plugins_to_close_after

        return False

    def is_control_type(self, sigmund_msg):
        return sigmund_msg.msg_type == self.plugin_name and Constants.CONTROL_MSG_TYPE in str(sigmund_msg.msg)

    @staticmethod
    def is_plugin_closing_type(sigmund_msg):
        return sigmund_msg.msg_type.startswith(f"{Constants.SIGMUND_PLUGIN_CLOSING}_")

    @staticmethod
    def get_plugin_closing_type_from_closing_plugin_msg_type(msg_type):
        return msg_type[len(f"{Constants.SIGMUND_PLUGIN_CLOSING}_"):]

    def get_next_message(self):
        """ Handle messages received from Sigmund to this plugin,
        and separate between Sigmund messages and other plugins' messages.
        Blocked until receiving the next message """

        if self.is_plugin_master:
            self.send_message(self.PLAYER_PLAY_NEXT_FRAMES_MESSAGE, str(self._master_num_of_frames_to_req))

        message = None
        message_handle_type = MessageTypeToHandle.Unknown

        while message_handle_type != MessageTypeToHandle.Input:
            message = self.sigmundTransport.get_next_msg()

            message_handle_type = self.handle_received_message_type(message)

            self.update_counter(message.msg_type, CounterType.InputCounter)

            if message_handle_type == MessageTypeToHandle.Input:
                break
            elif message_handle_type == MessageTypeToHandle.PassThrough:
                self.handle_pass_through_message(message)
            elif message_handle_type == MessageTypeToHandle.InBase:
                self.handle_message_in_base(message)
            elif message_handle_type == MessageTypeToHandle.Unknown:
                self.send_log(logging.WARNING, f"Received unknown message type {message.msg_type}")

        self.send_log(logging.NOTSET, f"{self.plugin_name} Received {message.msg_type} message from {message.msg_from}")
        return message

    def update_counter(self, message_type: str, counter_type: CounterType):
        """ Update the message counter of the given message type """
        if counter_type == CounterType.InputCounter:
            if message_type in self.messages_counters.InputTypesCounters:
                self.messages_counters.InputTypesCounters[message_type] += 1
            else:
                self.messages_counters.InputTypesCounters[message_type] = 1
        elif counter_type == CounterType.OutputCounter:
            if message_type in self.messages_counters.OutputTypesCounters:
                self.messages_counters.OutputTypesCounters[message_type] += 1
            else:
                self.messages_counters.OutputTypesCounters[message_type] = 1

    def handle_pass_through_message(self, sigmund_msg):
        self.on_message_pass_through(sigmund_msg)
        self.pass_through_message(sigmund_msg)
        self.send_log(logging.NOTSET, f"Passed through message {sigmund_msg.msg_type}")

    def handle_message_in_base(self, sigmund_msg):
        if self.is_control_type(sigmund_msg):
            self.handle_control(sigmund_msg)
        elif SigmundPluginBase.is_plugin_closing_type(sigmund_msg):
            closing_plugin_name = SigmundPluginBase.get_plugin_closing_type_from_closing_plugin_msg_type(sigmund_msg.msg_type)
            self.send_log(logging.INFO, f"Received plugin closing message from plugin: {closing_plugin_name}")
            self._plugins_to_close_after.remove(closing_plugin_name)

            if len(self._plugins_to_close_after) == 0:
                self.send_log(logging.INFO, f"All plugins to close after were closed, stopping plugin.")
                self.stop_plugin()

    def handle_control(self, sigmund_msg):
        # change the plugin input type
        if self.is_change_input_type_control(sigmund_msg):
            self.send_log(logging.DEBUG, f"ChangeInput message received: {sigmund_msg.msg}")
            old_type, new_type = self.parse_change_input_type_message(str(sigmund_msg.msg))
            self.modify_input_type(old_type, new_type)
            self.unsubscribe_to_single_type(old_type)
            self.subscribe_to_single_type(new_type)

        elif self.is_unregistered_type_control(sigmund_msg):
            self.send_log(logging.DEBUG, f"Unregister message received: {sigmund_msg.msg}")
            self.unsubscribe_all()
            self.send_log(logging.INFO, f"UnRegister completed")

        elif self.is_close_plugin_type_control(sigmund_msg):
            self.send_log(logging.INFO, f"Close plugin message received")
            self.stop_plugin()

        elif self.is_master_ack_type_control(sigmund_msg):
            self.handle_master_ack(sigmund_msg)

        elif self.is_master_nak_type_control(sigmund_msg):
            self.handle_master_nak(sigmund_msg)

        elif self.is_plugin_master and self.is_remove_master_indication_type_control(sigmund_msg):
            self.send_log(logging.INFO, f"{Constants.SIGMUND_REMOVE_MASTER_INDICATION} message received. "
                                        f"{self.plugin_name} is not Master anymore")
            self.is_plugin_master = False

        elif self.is_set_sigmund_log_min_level_type_control(sigmund_msg):
            min_sigmund_log_level_proto = LogMessageTypeProto.Value(sigmund_msg.msg_metadata)
            self.min_sigmund_log_level = PluginLogger.logtype_proto2python(min_sigmund_log_level_proto)

    @staticmethod
    def is_unregistered_type_control(sigmund_message):
        return (Constants.CONTROL_MSG_TYPE + Constants.SIGMUND_UNREGISTER) in str(sigmund_message.msg)

    @staticmethod
    def is_close_plugin_type_control(sigmund_message):
        return sigmund_message.msg == Constants.CONTROL_MSG_TYPE + Constants.SIGMUND_CLOSE_PLUGIN

    def modify_input_type(self, old_type: str, new_type: str):
        if old_type in self.input_types:
            self.input_types.Remove(old_type)
            self.input_types.Append(new_type)
        else:
            self.send_log(logging.WARN, f"old input type:{old_type} does not exist")

    def parse_change_input_type_message(self, str_to_parse: str):
        """ Get a control string and return tuple of old string and new string """
        regex_format = re.compile(re.escape(Constants.CONTROL_MSG_TYPE) +
                                  re.escape(self.CONTROL_CHANGE_INPUT_TYPE) + r"\((.*);(.*)\)")
        result = regex_format.search(str_to_parse)
        return [result.group(1), result.group(2)]

    @staticmethod
    def parse_register_ack_type_message(message):
        """ Get a Sigmund message and return new name and min log level to send"""
        regex_format = re.compile(re.escape(Constants.CONTROL_MSG_TYPE) +
                                  re.escape(Constants.SIGMUND_REGISTER_ACK) + r"\((.*)\)")
        result = regex_format.search(message.msg)
        new_name = result.group(1)
        min_sigmund_log_level_proto = LogMessageTypeProto.Value(message.msg_metadata)
        min_sigmund_log_level_python = PluginLogger.logtype_proto2python(min_sigmund_log_level_proto)
        return new_name, min_sigmund_log_level_python

    def is_change_input_type_control(self, sigmund_msg):
        return (Constants.CONTROL_MSG_TYPE + self.CONTROL_CHANGE_INPUT_TYPE) in str(sigmund_msg.msg)

    @staticmethod
    def is_register_ack_type_control(sigmund_message):
        return True if (Constants.CONTROL_MSG_TYPE + Constants.SIGMUND_REGISTER_ACK) in str(
            sigmund_message.msg) else False

    @staticmethod
    def is_master_ack_type_control(sigmund_message):
        return True if (Constants.CONTROL_MSG_TYPE + Constants.SIGMUND_MASTER_ACK) in str(
            sigmund_message.msg) else False

    @staticmethod
    def is_master_nak_type_control(sigmund_message):
        return True if (Constants.CONTROL_MSG_TYPE + Constants.SIGMUND_MASTER_NAK) in str(
            sigmund_message.msg) else False

    @staticmethod
    def is_remove_master_indication_type_control(sigmund_message):
        return True if (Constants.CONTROL_MSG_TYPE + Constants.SIGMUND_REMOVE_MASTER_INDICATION) in str(
            sigmund_message.msg) else False

    @staticmethod
    def is_set_sigmund_log_min_level_type_control(sigmund_message):
        return True if (Constants.CONTROL_MSG_TYPE + Constants.SIGMUND_SET_SIGMUND_LOG_MIN_LEVEL_TYPE) in str(
            sigmund_message.msg) else False

    def init_transport(self):
        try:
            self.sigmundTransport.init()
        except Exception as e:
            self.send_log(logging.FATAL, str(e))
            self._telemetry.track_exception(*sys.exc_info())

    def set_subscribers(self):
        types_to_subscribe = list()

        for input_type in self.input_types:
            types_to_subscribe.append(input_type)

        # Add close message type for plugins to close after to input types
        for plugin_to_close_after in self._plugins_to_close_after:
            types_to_subscribe.append(SigmundPluginBase.plugin_closing_msg_type(plugin_to_close_after))

        for input_change_type in self.input_change_types_dict.keys():
            input_change_type = input_change_type.replace(Constants.ANY_TYPE_CHAR, '')
            if input_change_type != '' and input_change_type not in types_to_subscribe:
                types_to_subscribe.append(input_change_type)

        for pass_through_type in self.pass_through_change_types_dict.keys():
            pass_through_type = pass_through_type.replace(Constants.ANY_TYPE_CHAR, '')
            if pass_through_type != '' and pass_through_type not in types_to_subscribe:
                types_to_subscribe.append(pass_through_type)

        for type_to_subscribe in types_to_subscribe:
            self.subscribe_to_single_type(type_to_subscribe)

    def set_subscriber_for_control_message(self):
        self.subscribe_to_single_type(self.plugin_name)

    def unsubscribe_all(self):
        for subscribed_type in self.input_types:
            self.unsubscribe_to_single_type(subscribed_type)

    def unsubscribe_to_single_type(self, subscribed_type: str):
        self.sigmundTransport.unsubscribe_type(subscribed_type)
        self.send_log(logging.DEBUG, f"Plugin unsubscribed to type: {subscribed_type}")

    def subscribe_to_single_type(self, subscribe_type: str):
        self.sigmundTransport.subscribe_type(subscribe_type)
        self.send_log(logging.DEBUG, f"plugin subscribed to type: {subscribe_type}")

    def send_log(self, log_type: int, log_message: str):
        """
        Send log message to Sigmund Log (and log in Plugin's log)
        :param log_type: python logging log type
        :param log_message: message to log
        """
        log_message = f"{self.plugin_name}: {log_message}"
        # Log message in plugin's log
        self._logger.log(log_type, log_message)

        if log_type >= self.min_sigmund_log_level:
            log_type_proto = PluginLogger.logtype_python2proto(log_type)
            self.send_message(self.SIGMUND_LOG_TYPE, log_message, str(log_type_proto))

    def change_output_type(self, message_type):
        if message_type in self.output_change_types_dict:
            message_type = self.output_change_types_dict[message_type]
        else:
            any_output_change = SigmundPluginBase.get_from_any_type_message_type_change(message_type,
                                                                                        self.output_change_types_dict)
            if any_output_change is not '':
                self.output_change_types_dict[message_type] = message_type = any_output_change

        return message_type

    def send_message(self, message_type: str, message: str, metadata=""):
        if message_type != self.SIGMUND_LOG_TYPE:
            self.send_log(logging.NOTSET, f"{self.plugin_name} send {message_type} message")

        message_type = self.change_output_type(message_type)

        self.sigmundTransport.send_message(message_type, message, metadata)
        self.update_counter(message_type, CounterType.OutputCounter)

    def pass_through_message(self, message: SigmundMsg):
        try:
            message_data = message.get_bytearray_message()
        except:
            message_data = message.get_string_message()

        self.sigmundTransport.send_message(message.msg_type, message_data, message.msg_metadata)
        self.update_counter(message.msg_type, CounterType.OutputCounter)

    # This is special LIB to handle json and classes, Since the usual "json.dump" is meant to be used with dictionary
    # This class is tested on simple classes. With complex classes other solution might be need
    def convert_class_to_json(self, class_to_convert):
        return jsonpickle.encode(class_to_convert)

    def convert_json_to_class(self, json_message, cls):
        decoded_json = json.loads(json_message)
        return cls(**decoded_json)

    def master_req_to_network(self):
        # Send MsasterReq message to Sigmund
        self.send_message(self.SIGMUND_TYPE, Constants.SIGMUND_MASTER_REQ)

        # wait until timeout for Master ack
        wait_ack_thread = threading.Thread(target=self.wait_for_master_ack, daemon=True)
        wait_ack_thread.start()
        wait_ack_thread.join(Constants.REGISTRATION_ACK_WAIT_TIMEOUT_SECONDS)

    def wait_for_master_ack(self):
        """ wait to receive Master ack message """
        while not self.is_plugin_master:
            message = self.sigmundTransport.get_next_msg()

            if self.is_control_type(message):
                # If received Master ack, plugin set to Master
                if self.is_master_ack_type_control(message):
                    self.handle_master_ack(message)

                # If received Master nak, plugin wasn't set to Master
                elif self.is_master_nak_type_control(message):
                    self.handle_master_nak(message)
                    break

    def handle_master_ack(self, message):
        """
        Received Master Ack. Set plugin as Master
        :param message: MasterAck message
        """
        self.send_log(logging.DEBUG, f"{Constants.SIGMUND_MASTER_ACK} message received: {message.msg}")
        self.send_log(logging.INFO, f"Plugin {self.plugin_name} is set to Master")
        self.is_plugin_master = True

    def handle_master_nak(self, message):
        """
        Received Master Nak. Failed to set plugin as Master.
        :param message: MasterNak message
        """
        self.send_log(logging.DEBUG, f"{Constants.SIGMUND_MASTER_NAK} message received: {message.msg}")
        self.send_log(logging.INFO, f"Plugin {self.plugin_name} was not set to Master")
        self.is_plugin_master = False

    @staticmethod
    def plugin_closing_msg_type(plugin_name: str):
        """
        :param plugin_name: Closing Plugin's name
        :return: The message type for plugin closing message
        """
        return f"{Constants.SIGMUND_PLUGIN_CLOSING}_{plugin_name}"

    def handle_received_message_type(self, message: SigmundMsg) -> MessageTypeToHandle:
        message_type = message.msg_type

        if message_type in self.input_change_types_dict:
            message.msg_type = self.input_change_types_dict[message_type]
            return MessageTypeToHandle.Input
        elif message_type in self.pass_through_change_types_dict:
            message.msg_type = self.pass_through_change_types_dict[message_type]
            return MessageTypeToHandle.PassThrough
        elif self.is_handle_message_in_base(message):
            return MessageTypeToHandle.InBase
        elif message_type == self.plugin_name:
            return MessageTypeToHandle.Input

        for input_type in self.input_types:
            if message_type.startswith(input_type):
                self.input_change_types_dict[message_type] = message_type
                return MessageTypeToHandle.Input

        any_input_type = SigmundPluginBase.get_from_any_type_message_type_change(
            message_type, self.input_change_types_dict)

        for input_type in self.input_types:
            if any_input_type.startswith(input_type) and any_input_type != '':
                self.input_change_types_dict[message_type] = message.msg_type = any_input_type
                return MessageTypeToHandle.Input

        any_pass_through_type = SigmundPluginBase.get_from_any_type_message_type_change(
            message_type, self.pass_through_change_types_dict)

        if any_pass_through_type != '':
            self.pass_through_change_types_dict[message_type] = message.msg_type = any_pass_through_type
            return MessageTypeToHandle.PassThrough

        return MessageTypeToHandle.Unknown

    @staticmethod
    def get_from_any_type_message_type_change(message_type: str, dict_to_check: dict):
        new_message_type = ""
        any_type_change = None

        for from_type in dict_to_check.keys():
            if Constants.ANY_TYPE_CHAR in from_type and message_type.startswith(
                    from_type.replace(Constants.ANY_TYPE_CHAR, '')) and from_type.replace(
                Constants.ANY_TYPE_CHAR, '') is not '':
                any_type_change = from_type
                break

        if any_type_change is None and Constants.ANY_TYPE_CHAR in dict_to_check.keys():
            any_type_change = Constants.ANY_TYPE_CHAR

        if any_type_change is not None:
            filtered_from_name = any_type_change.replace(Constants.ANY_TYPE_CHAR, '')

            if message_type.startswith(filtered_from_name):
                new_message_type = message_type.replace(filtered_from_name, "") if filtered_from_name != '' else message_type
                new_message_type = dict_to_check[any_type_change].replace(Constants.ANY_TYPE_CHAR, new_message_type)

        return new_message_type

    def fill_input_change_types_dict(self, input_change_types_list: list):
        if input_change_types_list is not None:
            SigmundPluginBase.get_type_changes_into_dict(input_change_types_list, self.input_change_types_dict)

            for type_change in input_change_types_list:
                split_name_change = type_change.split(Constants.TYPE_CHANGE_SEPERATOR)
                from_type = split_name_change[0] if split_name_change[0].endswith(
                    Constants.TYPE_CHANGE_SEPERATOR) else split_name_change[0] + Constants.ANY_TYPE_CHAR
                to_type = split_name_change[1] if split_name_change[1].endswith(
                    Constants.TYPE_CHANGE_SEPERATOR) else split_name_change[1] + Constants.ANY_TYPE_CHAR

                self.input_change_types_dict[from_type] = to_type

            for input_type in self.input_types:
                self.input_change_types_dict[input_type] = input_type

            self.input_change_types_dict[f"{self.plugin_name}*"] = f"{self.plugin_name}*"

    def fill_output_change_types_dict(self, output_change_types_list: list):
        if output_change_types_list is not None:
            SigmundPluginBase.get_type_changes_into_dict(output_change_types_list, self.output_change_types_dict)

            self.output_change_types_dict[f"{Constants.SIGMUND_MSG_TYPE}*"] = f"{Constants.SIGMUND_MSG_TYPE}*"
            self.output_change_types_dict[f"{Constants.SIGMUND_PLUGIN_CLOSING}*"] = f"{Constants.SIGMUND_PLUGIN_CLOSING}*"

    def fill_pass_through_change_types_dict(self, pass_through_change_types_list: list):
        if pass_through_change_types_list is not None:
            SigmundPluginBase.get_type_changes_into_dict(pass_through_change_types_list, self.pass_through_change_types_dict)

    @staticmethod
    def get_type_changes_into_dict(types_change_list: list, types_change_dict: dict):
        for type_change in types_change_list:
            split_name_change = type_change.split(Constants.TYPE_CHANGE_SEPERATOR)
            from_type = split_name_change[0]
            to_type = split_name_change[1]

            types_change_dict[from_type] = to_type
