import argparse
import sys
import time
from PyPluginBase.SigmundPluginBase import SigmundPluginBase


# Plugin must be running only after Sigmund core is up
class DummySenderPlugin(SigmundPluginBase):

    def __init__(self, plugin_name, output_types, num_msgs_to_send=None):
        SigmundPluginBase.__init__(self, plugin_name, [], output_types)
        self.num_msgs_to_send = num_msgs_to_send
        self.msgs_sent = 0

    def plugin_logic(self):
        print("DummySender send  " + str(self.msgs_sent) + " message")
        for out_type in self.output_types:
            self.send_message(out_type, "DummySender send  " + str(self.msgs_sent) + " message")

        self.msgs_sent += 1

        if self.num_msgs_to_send is not None and self.msgs_sent >= self.num_msgs_to_send:
            self.stop_plugin()


def parse_args(args=None):
    parser = argparse.ArgumentParser(description='Python dummy plugin arguments')
    parser.add_argument('-n', '--name', required=True, help='Plugin name')
    parser.add_argument('-o', '--output_types_str', default='', help="Output types with ',' separator")
    parser.add_argument('--num_msgs_to_send', default=None, type=int, help='Number of messages to send of each output type')

    args = parser.parse_args(args)
    return args


if __name__ == '__main__':
    parsed_args = parse_args(sys.argv[1:])
    output_types = parsed_args.output_types_str.split(",")
    sender_dummy = DummySenderPlugin(parsed_args.name, output_types, parsed_args.num_msgs_to_send)
    sender_dummy.start_plugin()
