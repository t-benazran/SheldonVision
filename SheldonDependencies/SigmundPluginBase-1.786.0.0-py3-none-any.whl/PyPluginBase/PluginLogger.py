import os
from datetime import datetime
import logging
import sys
from logging.handlers import TimedRotatingFileHandler
from SigmundProtobufPy.LogMessageType_pb2 import LogMessageTypeProto


class PluginLogger:
    LOGGER_NAME = "SigmundPy"
    LOG_FILES_DIR = "logs"
    FORMATTER = logging.Formatter(
        "%(asctime)s|%(levelname)s|%(message)s")
    base_logger = None

    @staticmethod
    def get_console_handler():
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(PluginLogger.FORMATTER)
        return console_handler

    @staticmethod
    def get_file_handler(log_path):
        file_handler = TimedRotatingFileHandler(log_path, when='midnight')
        file_handler.setFormatter(PluginLogger.FORMATTER)
        return file_handler

    @staticmethod
    def create_logger(plugin_class_name, log_level=logging.DEBUG):
        plugin_logs_dir = os.path.join(PluginLogger.LOG_FILES_DIR, f"{plugin_class_name}Py")

        if not os.path.isdir(plugin_logs_dir):
            os.makedirs(plugin_logs_dir)

        log_filepath = os.path.join(plugin_logs_dir, f"Plugin_{plugin_class_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")

        logger = logging.getLogger(PluginLogger.LOGGER_NAME)
        logger.setLevel(log_level)
        logger.addHandler(PluginLogger.get_console_handler())
        logger.addHandler(PluginLogger.get_file_handler(log_filepath))
        logger.propagate = False
        return logger

    @staticmethod
    def get_logger(class_name):
        # if PluginLogger.base_logger is None:
        PluginLogger.base_logger = PluginLogger.create_logger(class_name)
        return logging.getLogger(PluginLogger.LOGGER_NAME + "." + class_name)

    @staticmethod
    def logtype_python2proto(log_type):
        """
        Convert python logger log type to matching protobuf enum LogMessageTypeProto
        """
        if log_type == logging.NOTSET:  # python logging does not contain option for TRACE
            return LogMessageTypeProto.Value('Trace')
        if log_type == logging.DEBUG:
            return LogMessageTypeProto.Value('Debug')
        elif log_type == logging.INFO:
            return LogMessageTypeProto.Value('Info')
        elif log_type == logging.WARN:
            return LogMessageTypeProto.Value('Warn')
        elif log_type == logging.ERROR:
            return LogMessageTypeProto.Value('Error')
        elif log_type == logging.FATAL:
            return LogMessageTypeProto.Value('Fatal')

    @staticmethod
    def logtype_proto2python(log_type):
        """
        Convert protobuf enum LogMessageTypeProto to python logger log type
        """
        if log_type == LogMessageTypeProto.Value('Trace'):  # python logging does not contain option for TRACE
            return logging.NOTSET
        if log_type == LogMessageTypeProto.Value('Debug'):
            return logging.DEBUG
        elif log_type == LogMessageTypeProto.Value('Info'):
            return logging.INFO
        elif log_type == LogMessageTypeProto.Value('Warn'):
            return logging.WARN
        elif log_type == LogMessageTypeProto.Value('Error'):
            return logging.ERROR
        elif log_type == LogMessageTypeProto.Value('Fatal'):
            return logging.FATAL


# the python log types:
# CRITICAL = 50
# ERROR = 40
# WARNING = 30
# INFO = 20
# DEBUG = 10
# NOTSET = 0
