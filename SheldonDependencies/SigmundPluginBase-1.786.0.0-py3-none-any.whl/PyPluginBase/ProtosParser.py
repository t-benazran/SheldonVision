import glob
import importlib
import inspect

import pandas as pd
import numpy as np
from SigmundProtobufPy import *
from SigmundProtobufPy import LogMessageType_pb2, DftExtData_pb2
from SigmundProtobufPy.WindowType_pb2 import WindowTypeProto
from google.protobuf.json_format import MessageToDict
from google.protobuf.message import Message
from pandas import DataFrame

from .Consts import WINDOW_INDEX_COLUMN_NAME, CYCLE_NUMBER, WINDOW_INDEX_IN_CYCLE, WINDOW_TYPE, FREQ, AXIS, \
    NUMBER_ANTTENAS_PER_AXIS, ANT


class ProtosParser:
    def __init__(self):
        self._protos_attributes = {}
        self.__import_package_classes()

    def parse_proto(self, proto_name, proto_as_binary):
        """
        Parses binary data to a proto of the given type.
        :param proto_name: The name of the proto class.
        :param proto_as_binary: The proto in binary data.
        :return: An instance of the proto class parsed from the given binary data.
        """
        if proto_name not in self._protos_attributes:
            raise TypeError(f"The proto name {proto_name} is not found")

        class_attr = self._protos_attributes[proto_name]
        proto_instance = class_attr()
        proto_instance.ParseFromString(proto_as_binary)

        return proto_instance

    @staticmethod
    def protos_list_to_data_frame(protos_list: [Message]) -> DataFrame:
        """
        Parse list of proto objects to a DataFrame which contains all the protos properties data.
        :param protos_list: A list of proto objects (all the same proto type)
        :return: DataFrame containing the properties names as header, and the values as data (data of each proto in
            list is separate entry in the DataFrame)
        """
        protos_dictionaries = [ProtosParser.__proto_to_properties_dictionary(proto) for proto in protos_list]
        data_frame = pd.DataFrame.from_records(protos_dictionaries)

        return data_frame

    @staticmethod
    def __proto_to_properties_dictionary(proto: Message) -> {str: str}:
        """
        Parse proto object to dictionary of {property name : property value}
        """
        properties_dictionary = MessageToDict(proto, including_default_value_fields=True)

        reordered_properties_dictionary = ProtosParser.__reorder_properties_dictionary(properties_dictionary)
        flattened_properties_dictionary = {}

        for key, val in reordered_properties_dictionary.items():
            flattened_properties_dictionary.update(ProtosParser.__flatten_complex_property_to_dict(key, val))
        return flattened_properties_dictionary
    
    @staticmethod
    def cast_windows_type(window_type_value):
        return f"{WindowTypeProto.Name(int(window_type_value))}_{WindowTypeProto.Value(WindowTypeProto.Name(int(window_type_value)))}"
        
    @staticmethod
    def __flatten_complex_property_to_dict(property_name: str, property_obj) -> {str: object}:
        property_dict = {}

        if is_dict(property_obj):
            for key, val in property_obj.items():
                property_dict.update(ProtosParser.__flatten_complex_property_to_dict(f"{property_name}_{key}", val))

        elif is_list(property_obj) and len(property_obj) > 0:
            if not is_dict(property_obj[0]) and not is_list(property_obj[0]):
                property_dict = {property_name: str(property_obj)}
            else:
                for i, item in enumerate(property_obj):
                    property_dict.update(ProtosParser.__flatten_complex_property_to_dict(f"{property_name}_{i}", item))

        else:
            property_dict = {property_name: property_obj}

        return property_dict

    @staticmethod
    def cast_windows_type(window_type_value):
        return f"{WindowTypeProto.Name(int(window_type_value))}_{WindowTypeProto.Value(WindowTypeProto.Name(int(window_type_value)))}"

    @staticmethod
    def __reorder_properties_dictionary(properties_dictionary):
        reordered_properties_dictionary = {}
        cycle_num = properties_dictionary.pop(CYCLE_NUMBER, None)
        window_index = properties_dictionary.pop(WINDOW_INDEX_COLUMN_NAME, None)
        window_type = properties_dictionary.pop(WINDOW_TYPE, None)

        for col_nam, value in [(CYCLE_NUMBER, cycle_num),
                               (WINDOW_INDEX_COLUMN_NAME, window_index),
                               (WINDOW_TYPE, window_type)]:
            if value is not None:
                reordered_properties_dictionary[col_nam] = f"{value}_{WindowTypeProto.Value(value)}" if col_nam == WINDOW_TYPE else value

        reordered_properties_dictionary.update(properties_dictionary)

        return reordered_properties_dictionary

    def __import_package_classes(self):
        protos_package_path = os.path.dirname(LogMessageType_pb2.__file__)
        package_name = os.path.basename(protos_package_path)

        # Iterate all python files within that directory
        modules_file_paths = glob.glob(os.path.join(protos_package_path, "*.py"))
        for module_file_path in modules_file_paths:
            module_file_name = os.path.basename(module_file_path)
            module_name = os.path.splitext(module_file_name)[0]

            if module_name.startswith("__"):
                continue

            # -----------------------------
            # Import python file
            module = importlib.import_module("." + module_name, package=package_name)

            # -----------------------------
            # Iterate items inside imported python file
            for class_in_module in dir(module):
                class_attr = getattr(module, class_in_module)

                if not class_attr or not inspect.isclass(class_attr):
                    continue

                self._protos_attributes[class_in_module] = class_attr
    
    @staticmethod
    def cast_windows_type(window_type_value):
        return f"{WindowTypeProto.Name(int(window_type_value))}_{WindowTypeProto.Value(WindowTypeProto.Name(int(window_type_value)))}"
        
    @staticmethod
    def DftExtDataProto_list_to_data_frame(protos_list: [Message]) -> DataFrame:
        """
        Order DftExtData proto into readbale struct for display as table and create plots
        :param protos_list:
        :return:
        """
        data = [pd.DataFrame.from_dict(ProtosParser.__DftExtData_to_df(proto)) for proto in protos_list]
        return pd.concat(data)

    @staticmethod
    def __DftExtData_to_df(proto):
        """
        Parse order DftExtData to ordered dictionary
        :param proto: DftExtProto
        :return:
        """
        data = {
            CYCLE_NUMBER: [],
            WINDOW_INDEX_IN_CYCLE: [],
            WINDOW_TYPE: [],
            FREQ: [],
            AXIS: [],
            NUMBER_ANTTENAS_PER_AXIS: []
        }
        freqs = list(proto.CorrFreqsPerAxis[0].CorrFreqs)
        proto = proto.DftData

        num_of_ant_per_axis = [proto.DftDataPerAxis[x].NumOfAntsInAxis for x in
                               range(0, len(proto.DftDataPerAxis))]

        location_ant = 0
        for axis in range(0, len(proto.DftDataPerAxis)):

            for freq in range(0, len(proto.DftDataPerAxis[axis].DftPerFreq)):
                data[AXIS].append(axis)
                data[FREQ].append(freqs[freq])
                data[CYCLE_NUMBER].append(proto.CycleIndex)
                data[WINDOW_INDEX_IN_CYCLE].append(proto.WindowIndexInCycle)
                data[WINDOW_TYPE].append(f"{ProtosParser.cast_windows_type(proto.WindowType)}")

                for ant in range(0, len(proto.DftDataPerAxis[axis].DftPerFreq[freq].DftPerAntenna)):

                    complex_data = create_complex_data(proto, freq, axis, ant)
                    if f'{ANT}{ant}' not in data.keys():
                        data[f'{ANT}{ant}'] = []
                    data[f'{ANT}{ant}'].append(np.linalg.norm(complex_data))
            location_ant += num_of_ant_per_axis[axis]
        for key, item in data.items():
            data_length = len(freqs) * (len(proto.DftDataPerAxis))
            if len(item) <= data_length:
                data[key] = pad(item, data_length, 0)
        return data


def is_list(obj):
    return isinstance(obj, list)


def is_dft_ext_data(obj):
    return isinstance(obj, DftExtData_pb2.DftExtDataProto)


def is_dict(obj):
    return isinstance(obj, dict)


def pad(item, size, padding):
    return item + [padding] * abs((len(item) - size))


def create_complex_data(proto, freq, axis, ant):
    """
    create_complex_data from real and imaginary values
    @param proto: proto file
    @param freq: frequency of data
    @param axis: range of antenna the make a loop
    @param ant: antenna
    @return: complex data
    """
    real_dft_value = proto.DftDataPerAxis[axis].DftPerFreq[freq].DftPerAntenna[ant].DftValue.Real
    imaginary_dft_value = proto.DftDataPerAxis[axis].DftPerFreq[freq].DftPerAntenna[ant].DftValue.Imaginary
    complex_data = np.complex(real_dft_value, imaginary_dft_value)
    return complex_data
