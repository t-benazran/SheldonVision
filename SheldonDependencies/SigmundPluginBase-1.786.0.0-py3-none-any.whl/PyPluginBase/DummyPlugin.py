import argparse
import os
import sys

package_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir))
sys.path.append(package_path)

from PyPluginBase.SigmundPluginBase import SigmundPluginBase
from PyPluginBase.Transport import ISigmundTransport
from PyPluginBase.Common import Constants


# example for class that listening for messages
# and send back messages to another plugin
# Plugin must be running only after Sigmund core is up
# then run "DummySender" and watch messages received here
class DummyPlugin(SigmundPluginBase):

    def __init__(self, plugin_name, input_types, output_types,
                 input_types_change_list=None, output_types_change_list=None, pass_through_types=None,
                 sigmund_transport: ISigmundTransport = None,
                 master=False, master_num_of_frames_to_req=Constants.DEFAULT_PLAY_FRAMES_NUM,
                 wait_registration_ack_timeout_sec=Constants.REGISTRATION_ACK_WAIT_TIMEOUT_SECONDS,
                 plugins_to_close_after=None):
        SigmundPluginBase.__init__(self, plugin_name, input_types, output_types,
                                   input_types_change_list, output_types_change_list, pass_through_types,
                                   sigmund_transport, master,
                                   master_num_of_frames_to_req, wait_registration_ack_timeout_sec,
                                   plugins_to_close_after=plugins_to_close_after)
        self.messages = []

    def plugin_logic(self):
        message = self.get_next_message()
        self.send_message("DummyReceived", message.msg_type)
        print(message.msg_type)
        self.messages.append(message)


def parse_args(args=None):
    parser = argparse.ArgumentParser(description='Python dummy plugin arguments')
    parser.add_argument('-n', '--name', required=True, help='Plugin name')
    parser.add_argument('-i', '--input_types_str', default=None, help="Input types with ',' separator")
    parser.add_argument('-o', '--output_types_str', default=None, help="Output types with ',' separator")
    parser.add_argument('--master', help="Flag to set plugin as Master", required=False, action="store_true",
                        default=False)
    parser.add_argument('--master_num_of_frames_to_req', help="Frames number that Master ask from player",
                        required=False, type=int, default=Constants.DEFAULT_PLAY_FRAMES_NUM)
    parser.add_argument('--plugins_to_close_after', default=None,
                        help="Plugin names to close after they close with ',' separator")
    parser.add_argument('--num_msgs_to_collect', default=None, type=int, help='Number of messages to collect')
    parser.add_argument('--inputNameChange', required=False, default=None,
                        help="Input types to change with ',' separator")
    parser.add_argument('--outputNameChange', required=False, default=None,
                        help="Output types to change with ',' separator")
    parser.add_argument('--passthrough', required=False, default=None,
                        help="Types to pass through with ',' separator")

    args = parser.parse_args(args)
    return args


def parse_value_to_array_if_not_none_else_empty_array(array_str):
    if array_str is not None:
        return array_str.split(",")
    return []


if __name__ == '__main__':
    parsed_args = parse_args(sys.argv[1:])
    plugin_input_types = parse_value_to_array_if_not_none_else_empty_array(parsed_args.input_types_str)
    plugin_output_types = parse_value_to_array_if_not_none_else_empty_array(parsed_args.output_types_str)
    plugin_input_types_change_list = parse_value_to_array_if_not_none_else_empty_array(parsed_args.inputNameChange)
    plugin_output_types_change_list = parse_value_to_array_if_not_none_else_empty_array(parsed_args.outputNameChange)
    plugin_pass_through_types_list = parse_value_to_array_if_not_none_else_empty_array(parsed_args.passthrough)
    plugins_to_close_after_list = parse_value_to_array_if_not_none_else_empty_array(parsed_args.plugins_to_close_after)
    dummy = DummyPlugin(parsed_args.name, plugin_input_types, plugin_output_types,
                        plugin_input_types_change_list, plugin_output_types_change_list, plugin_pass_through_types_list,
                        master=parsed_args.master,
                        master_num_of_frames_to_req=parsed_args.master_num_of_frames_to_req,
                        plugins_to_close_after=plugins_to_close_after_list)
    dummy.start_plugin()
