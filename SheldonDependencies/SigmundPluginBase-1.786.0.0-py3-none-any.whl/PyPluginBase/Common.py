from SigmundProtobufPy.MessageDataType_pb2 import eSigmundPayloadTypeProto
from enum import Enum


class MessageDataTypeEnums:
    @staticmethod
    def get_str_message_datatype():
        return eSigmundPayloadTypeProto.Value('STRING')

    @staticmethod
    def get_bytearray_message_datatype():
        return eSigmundPayloadTypeProto.Value('BYTEARRAY')


class MessageTypeToHandle(Enum):
    Input = 0
    PassThrough = 1
    InBase = 2
    Unknown = 3


class CounterType(Enum):
    InputCounter = 0,
    OutputCounter = 1


# todo config file - Task 1242391 [Sigmund] Protocol buffer and configuration file for base classes
class Constants:
    # Connection settings
    IP_ADDRESS = "127.0.0.1"
    SUB_PORT = "1234"
    PUB_PORT = "5678"
    KEEP_ALIVE_PORT = "2468"

    # Parsing messages
    LIST_DELIMITER = ","
    LIST_DELIMITER_CHAR = ';'
    MESSAGE_DELIMITER = ";"
    MESSAGE_DELIMITER_CHAR = ';'

    # Network topology
    ANY_TYPE_CHAR = "*"
    TYPE_CHANGE_SEPERATOR = ':'

    # Messages
    SIGMUND_REGISTER_TYPE = "RegisterPlugin"
    SIGMUND_REGISTER_ACK = "RegistryAck"
    SIGMUND_UNREGISTER = "UnRegistry"
    SIGMUND_CLEAR_NOT_RUNNING = "ClearNotRunning"
    SIGMUND_CLOSE_NETWORK_SOFT = "CloseNetworkSoft"
    SIGMUND_CLOSE_NETWORK_HARD = "CloseNetworkHard"
    SIGMUND_PLUGIN_CLOSING = "PluginClosing"  # plugin notify core before closing
    SIGMUND_CLOSE_PLUGIN = "ClosePlugin"  # core command plugin to close
    CONTROL_MSG_TYPE = "#Control#."
    SIGMUND_MSG_TYPE = "Sigmund"
    SIGMUND_SET_LOG_MIN_LEVEL_TYPE = "SetLogMinLevel"
    PLUGIN_COUNTERS_MSG_TYPE = "PluginCounters"
    START_SEND_NETWORK_INFO_MSG_TYPE = "StartSendNetworkInformation"
    NETWORK_INFO_MSG_TYPE = "NetworkInformation"
    METADATA_FILE_NAME = "FileName"
    METADATA_DELIMITER = "#%"
    SIGMUND_MASTER_REQ = "MasterReq"
    SIGMUND_MASTER_ACK = "MasterAck"
    SIGMUND_MASTER_NAK = "MasterNak"
    SIGMUND_RESET_MASTER = "ResetMaster"
    SIGMUND_FORCE_MASTER = "ForceMaster"
    SIGMUND_REMOVE_MASTER_INDICATION = "RemoveMasterIndication"
    SIGMUND_SET_SIGMUND_LOG_MIN_LEVEL_TYPE = "SetLogMinLevel"
    SIGMUND_NETWORK_TIMEOUT_ELAPSED = "NetworkTimeoutElapsed"
    SIGMUND_KEEP_ALIVE_MESSAGE = "KeepAlive"
    RECORDING_STARTED_MSG_TYPE = "RecordingStarted";
    RECORD_REQUEST_MSG_TYPE = "RecordRequest";
    STOP_RECORD_MSG_TYPE = "StopRecord";
    RECORDER_FAILED_MSG_TYPE = "RecorderFailed";
    RECORD_INDICATION_MSG_TYPE = "RecordIndication";
    RECORD_INDICATION_FLASH_MSG_TYPE = "RecordIndicationFlash";
    RECORD_INDICATION_DONE_MSG_TYPE = "RecordIndicationDone";
    RECORD_STATISTICS_MSG_TYPE = "RecordStatistics";
    INIT_RECORDING_RECORD_STATISTICS_MSG_TYPE = "InitRecordingRecordStatistics";
    SIGMUND_RAISE_NETWORK = "RaiseNetwork";
    GET_SIGMUND_VERSION = "GetSigmundVersion";
    SIGMUND_VERSION = "SigmundVersion";

    # Times
    SOCKET_OPEN_WAIT_TIME_SECONDS = 0.5
    TIMEOUT_GET_MESSAGE_MILLISECONDS = 10
    REGISTRATION_ACK_WAIT_TIMEOUT_SECONDS = 1
    NUMBER_OF_REGISTRATION_RETRIES = 6
    SEND_COUNTERS_INTERVAL_SEC = 1
    CORE_DISCONNECT_NO_KEEP_ALIVE_TIMEOUT_SECONDS = 5
    TIME_TO_POLL_FOR_KEEP_ALIVE_MESSAGE_MILLISECONDS = 25

    # Default frames num that Master requests
    DEFAULT_PLAY_FRAMES_NUM = 30

    # Exit codes
    ERROR_EXIT_CODE = 1
