
class PluginStoppedException(Exception):
    pass

